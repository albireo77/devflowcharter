#include <stdio.h>

char tmp[100];
FILE *p1;
int i;

int main()
{

	system("cls");
	printf("\n\n");
	printf("---------------- devFlowcharter Pascal compiler Auto Configure -----------------\n");
	printf("                                  by phoeagon");
	printf("\n\n");
	printf(" NO WARRANTY!\n This program is distributed as a free software according to GPL.\n");
	printf(" The compiler attached is part of Free Pascal (www.freepascal.org), distributed\n");
	printf(" under GPL.\n\n");
	printf(" This program attempts to modify Windows registry to setup attached compiler as\n");
	printf(" Pascal compiler for devFlowcharter.\n");

	//retrieving the current dir
	p1 = popen("cd","r");
	fgets(tmp, 100, p1);
	pclose(p1);
	tmp[strlen(tmp)-1] = 0;
	for (i = 0; i < strlen(tmp); ++i)
	{
		if (tmp[i] == ' ')
		{
			printf("\n Current compiler path \"%s\"\n", tmp);
            printf(" contains spaces that are not allowed.\n");
			printf(" Installation aborted!\n");
			getchar();
			return 1;
		}
	}

	printf(" Do you want to continue? (y/n) ");
	char xx = getchar();
	if (xx == 'y')
	{
		//generating the reg file
		p1 = fopen("install.reg","w");
		fprintf(p1,"Windows Registry Editor Version 5.00\n"
			"[HKEY_CURRENT_USER\\Software\\devFlowcharter]\n");
		i = strlen(tmp);
		sprintf(tmp+i, "\\bin\\fpc.bat");
		fprintf(p1, "\"CompilerPath_Pascal\"=");
		fprintf(p1, "\"");

		int n = strlen(tmp);
		for (i = 0; i < n; ++i)
		{
			fputc(tmp[i], p1);
			if (tmp[i] == '\\')
				fputc(tmp[i], p1);
		}
		fprintf(p1, " \\\"%%s1\\\"\"");
		fclose(p1);

		system("install.reg");
		system("del install.reg");
	}

}
